// Re-export from common crate
pub use common::asset_rpc_client::{deposit, init_asset_client, merge, redeem, split, trade_onchain_send_result, withdraw};
