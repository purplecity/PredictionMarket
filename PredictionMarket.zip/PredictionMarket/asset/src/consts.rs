pub const PROCESSING_TIMEOUT_SECS: u64 = 10;

/// 用户事件批量发送的最大批次大小
pub const USER_EVENT_BATCH_SIZE: usize = 100;
