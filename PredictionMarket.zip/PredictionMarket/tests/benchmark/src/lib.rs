//! Match Engine Benchmark Library
//!
//! 提供压测场景和报告生成功能

pub mod reporter;
pub mod scenarios;
