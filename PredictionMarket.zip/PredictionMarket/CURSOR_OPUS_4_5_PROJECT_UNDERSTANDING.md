# Prediction Market 系统架构理解文档

## 📋 项目概述

这是一个 **高性能预测市场撮合引擎系统**，使用 Rust 编写，采用微服务架构。系统支持用户对各类事件（如加密货币价格、体育赛事、政治事件等）进行预测交易。

### 核心特性
- 高性能内存撮合引擎（价格优先、时间优先）
- 支持限价单和市价单
- 交叉撮合机制（Yes/No 二元期权）
- 实时 WebSocket 推送
- 链上交易结算
- 完善的资产管理

---

## 🏗️ 系统架构

### 服务组件一览

```
┌─────────────────────────────────────────────────────────────────────┐
│                          用户层                                      │
│  ┌─────────┐  ┌───────────────┐  ┌────────────────────────────┐    │
│  │ REST API│  │ WebSocket深度 │  │ WebSocket用户              │    │
│  │ (api)   │  │(websocket_depth)│ │(websocket_user)           │    │
│  └────┬────┘  └───────┬───────┘  └─────────────┬──────────────┘    │
└───────┼───────────────┼────────────────────────┼────────────────────┘
        │               │                        │
┌───────┼───────────────┼────────────────────────┼────────────────────┐
│       ▼               ▼                        ▼                    │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Redis Streams (消息队列)                   │   │
│  │  order_input_stream | store_stream | processor_stream       │   │
│  │  websocket_stream   | cache_stream | onchain_stream         │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│       ┌──────────────────────┼──────────────────────┐              │
│       ▼                      ▼                      ▼              │
│  ┌──────────┐         ┌──────────┐          ┌──────────┐          │
│  │ Match    │         │ Store    │          │Processor │          │
│  │ Engine   │◄───────►│ Service  │◄────────►│ Service  │          │
│  │(撮合引擎)│         │(状态持久化)│         │(结果处理)│          │
│  └────┬─────┘         └──────────┘          └────┬─────┘          │
│       │                                          │                 │
│       ▼                                          ▼                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────┐         │
│  │ Depth    │  │ Event    │  │ Asset    │  │OnchainMsg │         │
│  │ Service  │  │ Service  │  │ Service  │  │ Service   │         │
│  │(深度聚合)│  │(事件管理)│  │(资产管理)│  │(链上交互) │         │
│  └──────────┘  └──────────┘  └──────────┘  └───────────┘         │
│                              业务层                                 │
└────────────────────────────────────────────────────────────────────┘
                               │
                               ▼
        ┌──────────────────────────────────────────┐
        │              数据存储层                   │
        │  ┌──────────────┐  ┌──────────────────┐  │
        │  │  PostgreSQL  │  │      Redis       │  │
        │  │ (持久化存储)  │  │  (缓存/消息队列) │  │
        │  └──────────────┘  └──────────────────┘  │
        └──────────────────────────────────────────┘
```

---

## 📦 服务详解

### 1. Match Engine（撮合引擎）- 核心服务
**路径**: `match_engine/`

**功能**:
- 接收订单请求，执行内存撮合
- 维护每个 market/token 的订单簿（OrderBook）
- 使用 BTreeMap 实现价格优先级排序
- 支持交叉撮合（Yes 的买单可以与 No 的买单匹配）

**核心数据结构**:
```rust
// 订单簿结构
pub struct OrderBook {
    pub symbol: PredictionSymbol,       // 市场标识
    pub bids: BTreeMap<i32, Vec<Order>>, // 买单（负价格key实现降序）
    pub asks: BTreeMap<i32, Vec<Order>>, // 卖单
    pub order_price_map: HashMap<String, (OrderSide, i32)>, // 订单快速查找
}
```

**撮合逻辑**:
- 同结果撮合：Buy vs Sell（价格匹配）
- 交叉撮合：Buy(Yes) vs Buy(No)，price_yes >= 10000 - price_no

### 2. Store Service（状态持久化）
**路径**: `store/`

**功能**:
- 消费撮合引擎的订单变化事件
- 维护内存订单状态
- 定期保存快照到 `./data/store/orders_snapshot.json`
- 重启时从快照恢复

### 3. API Service（REST API）
**路径**: `api/`

**功能**:
- 提供用户面向的 REST API
- 订单提交/取消
- 用户信息管理
- 市场数据查询

**主要端点**:
| 端点 | 方法 | 说明 |
|------|------|------|
| `/events` | GET | 获取事件列表 |
| `/event_detail` | GET | 获取事件详情 |
| `/depth` | GET | 获取市场深度 |
| `/place_order` | POST | 下单 |
| `/cancel_order` | POST | 取消订单 |
| `/positions` | GET | 获取持仓 |
| `/open_orders` | GET | 获取未成交订单 |

### 4. Asset Service（资产管理）
**路径**: `asset/`

**功能**:
- 管理用户资产（USDC 和 Token）
- 处理充值/提现
- 订单冻结/解冻资产
- Split（拆分 USDC 为 Token）
- Merge（合并 Token 为 USDC）
- Redeem（赎回获胜 Token）

**gRPC 接口**:
```protobuf
service AssetService {
  rpc Deposit(DepositRequest) returns (Response);
  rpc Withdraw(WithdrawRequest) returns (Response);
  rpc CreateOrder(CreateOrderRequest) returns (CreateOrderResponse);
  rpc CancelOrder(CancelOrderRequest) returns (ResponseWithUpdateId);
  rpc Trade(TradeRequest) returns (TradeResponse);
  rpc Split(SplitRequest) returns (Response);
  rpc Merge(MergeRequest) returns (Response);
  rpc Redeem(RedeemRequest) returns (Response);
}
```

### 5. Processor Service（结果处理）
**路径**: `processor/`

**功能**:
- 消费撮合结果
- 调用 Asset Service 更新资产
- 转发到链上交易服务
- 推送到 WebSocket 服务

### 6. Depth Service（深度聚合）
**路径**: `depth/`

**功能**:
- 聚合订单簿深度数据
- 计算价格档位
- 推送深度变化到 WebSocket

### 7. Event Service（事件管理）
**路径**: `event/`

**功能**:
- 管理预测市场事件生命周期
- 创建/关闭市场
- 事件结算

### 8. OnchainMsg Service（链上交互）
**路径**: `onchain_msg/`

**功能**:
- 处理链上交易请求
- 监听链上事件（充值/提现/Split/Merge/Redeem）
- 与智能合约交互

### 9. WebSocket Services
**路径**: `websocket_depth/`, `websocket_user/`

**websocket_depth** - 市场深度推送:
```json
// 连接确认
{"event_type": "connected", "id": "<uuid>"}
// 订阅
{"action": "subscribe", "event_id": 1, "market_id": 1}
```

**websocket_user** - 用户数据推送:
```json
// JWT 认证
{"auth": "<privy-jwt-token>"}
// 认证响应
{"event_type": "auth", "success": true}
```

---

## 📊 数据模型

### 核心类型

**Symbol（市场标识）**:
```
格式: event_id|market_id|token_id
示例: 1|1|0x123abc
```

**Order（订单）**:
```rust
pub struct Order {
    pub order_id: String,
    pub symbol: PredictionSymbol,
    pub side: OrderSide,           // Buy/Sell
    pub order_type: OrderType,     // Limit/Market
    pub quantity: u64,             // 数量 × 100
    pub price: i32,                // 价格 × 10000 [100-9900]
    pub opposite_result_price: i32, // = 10000 - price
    pub status: OrderStatus,
    pub filled_quantity: u64,
    pub remaining_quantity: u64,
    pub timestamp: i64,
    pub user_id: i64,
    pub order_num: u64,            // 时间优先序号
}
```

**Price Range**:
- 有效价格范围: 0.0100 - 0.9900
- 内部表示: 100 - 9900（乘以 10000）
- Yes + No 价格 = 1.0000（10000）

### 数据库表

| 表名 | 说明 |
|------|------|
| `users` | 用户信息（Privy 认证） |
| `events` | 预测事件 |
| `orders` | 订单记录 |
| `trades` | 成交记录 |
| `positions` | 用户持仓 |
| `asset_history` | 资产变动历史 |
| `operation_history` | 操作历史 |

---

## 🔄 数据流

### 订单处理流程
```
1. 用户下单 → API Service
2. API 验证 → 调用 Asset Service (冻结资产)
3. Asset Service 成功 → 发送到 order_input_stream
4. Match Engine 消费 → 内存撮合
5. 撮合结果 → 多路输出:
   ├── store_stream → Store Service (持久化)
   ├── processor_stream → Processor Service
   │   ├── 调用 Asset Service (更新资产)
   │   └── 发送到 onchain_stream → OnchainMsg Service
   ├── websocket_stream → WebSocket Services
   └── cache_stream → Depth Service
```

### 链上交易流程
```
1. Processor → onchain_stream (发送交易请求)
2. OnchainMsg → 构造链上交易 → 发送到区块链
3. 交易确认 → onchain_response_stream
4. Processor 消费响应 → 调用 Asset Service 最终确认
```

---

## ⚙️ 配置管理

### 环境变量（common.env）
```env
run_mode="dev"                        # 运行模式
engine_input_mq_redis_host="..."      # 撮合引擎输入 Redis
engine_output_mq_redis_host="..."     # 撮合引擎输出 Redis
websocket_mq_redis_host="..."         # WebSocket Redis
postgres_read_host="..."              # PostgreSQL 读库
postgres_write_host="..."             # PostgreSQL 写库
asset_rpc_url="..."                   # Asset Service gRPC
privy_pem_key="..."                   # Privy JWT 验证公钥
```

### 服务配置（deploy/service/dev.toml）
```toml
[logging]
level = "info"
file = "./logs/service.log"
console = true
rotation_max_files = 3

[engine_input_mq]
db = 0
batch_size = 100
```

---

## 🔑 关键设计决策

### 1. 价格时间优先撮合
- BTreeMap 实现价格排序
- 买单使用负价格 key（实现降序）
- 同价格按时间戳顺序（FIFO）

### 2. 交叉撮合机制
预测市场特有，Yes 和 No 互为对手盘：
- Buy(Yes, 0.65) 可匹配 Buy(No, 0.35)
- 因为: 0.65 + 0.35 = 1.00

### 3. 无 WAL 设计
- 依赖 Redis Stream 可靠性
- 优雅停机确保状态一致
- 快照恢复机制

### 4. 并发安全
- `Arc<RwLock<T>>` 共享状态
- 基于 hash 的任务路由
- 分布式锁处理并发更新

### 5. 消息去重
- SlidingWindowDedup 滑动窗口去重
- 防止重复订单处理

---

## 🛠️ 开发命令

```bash
# 构建
cargo build --release

# 运行服务
export RUN_MODE=dev
cargo run --bin match_engine
cargo run --bin store
cargo run --bin api
cargo run --bin asset
cargo run --bin processor
cargo run --bin depth
cargo run --bin onchain_msg
cargo run --bin websocket_depth
cargo run --bin websocket_user

# 测试
cargo test
cargo test -p match_engine

# 代码质量
cargo fmt
cargo clippy
```

---

## 📁 目录结构

```
PredictionMarket/
├── api/                 # REST API 服务
├── asset/               # 资产管理服务
├── common/              # 公共库（类型定义、工具）
├── depth/               # 深度聚合服务
├── event/               # 事件管理服务
├── match_engine/        # 撮合引擎（核心）
├── onchain_msg/         # 链上消息服务
├── processor/           # 结果处理服务
├── proto/               # gRPC 协议定义
├── store/               # 状态持久化服务
├── websocket_depth/     # 深度 WebSocket
├── websocket_user/      # 用户 WebSocket
├── deploy/              # 部署配置
├── script/              # 运维脚本
├── data/                # 数据文件
└── logs/                # 日志文件
```

---

## 🔗 技术栈

| 类别 | 技术 |
|------|------|
| 语言 | Rust |
| 异步运行时 | Tokio |
| Web 框架 | Axum |
| RPC | Tonic (gRPC) |
| 消息队列 | Redis Streams |
| 数据库 | PostgreSQL + SQLx |
| 序列化 | Serde / JSON |
| 认证 | Privy JWT |
| 日志 | Tracing |

---

## 📈 性能考量

1. **内存撮合**: 订单簿完全在内存中，撮合延迟极低
2. **消费者组**: Redis Streams 支持多消费者并行处理
3. **快照恢复**: 定期快照 + 增量消息，快速恢复
4. **读写分离**: PostgreSQL 支持读写分离
5. **连接池**: 数据库和 Redis 均使用连接池

---

## 🎯 总结

这是一个设计精良的预测市场系统，具有以下特点：

1. **高性能**: 内存撮合 + 异步 IO
2. **高可靠**: 消息队列 + 快照恢复
3. **可扩展**: 微服务架构 + 服务解耦
4. **安全性**: JWT 认证 + 链上结算
5. **实时性**: WebSocket 推送 + 事件驱动

系统适用于高频交易场景，能够处理大量并发订单，同时保证数据一致性和可追溯性。
