#! /bin/sh
buf format -w