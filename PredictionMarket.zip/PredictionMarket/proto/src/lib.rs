// 生成proto代码
pub mod asset;
pub use asset::*;
