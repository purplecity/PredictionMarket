# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

This is a high-performance prediction market matching engine system written in Rust, consisting of multiple microservices that communicate via Redis Streams. The system handles order matching, asset management, market creation, and real-time data distribution.

## Development Commands

### Building and Running

```bash
# Build all workspace members
cargo build

# Build in release mode
cargo build --release

# Run a specific service (set RUN_MODE=dev or prod)
export RUN_MODE=dev
cargo run --bin match_engine
cargo run --bin store
cargo run --bin api
cargo run --bin api_query
cargo run --bin market
cargo run --bin asset
cargo run --bin websocket
cargo run --bin processor
cargo run --bin depth
cargo run --bin onchain_msg
```

### Testing

```bash
# Run all tests
cargo test

# Run tests for a specific package
cargo test -p match_engine

# Run a specific test
cargo test --test match_engine_tests
```

### Code Quality

```bash
# Format code (uses custom rustfmt.toml with tabs, max_width=200)
cargo fmt

# Run clippy (max 8 arguments per function allowed)
cargo clippy

# Check without building
cargo check
```

## Architecture

### Core Services

The system is organized as a Cargo workspace with the following services:

1. **match_engine**: The heart of the system - receives orders via Redis Streams, maintains in-memory orderbooks per market/option, executes matches using price-time priority, and publishes results to multiple output streams.

2. **store**: Consumes order change events from match_engine, maintains in-memory order state, periodically saves snapshots to `./data/store/orders_snapshot.json`, and handles graceful recovery on restart.

3. **api**: User-facing REST API for order submission and cancellation. Publishes order requests to Redis Streams for match_engine consumption. Uses Axum framework with graceful shutdown support.

4. **api_query**: Read-only query API for market data, order history, and trade information. Separate from write API to optimize read performance.

5. **market**: Market lifecycle management service - creates and closes markets, manages market states and options.

6. **asset**: Handles user asset management - deposits, withdrawals, freezing/unfreezing assets for orders.

7. **websocket**: Real-time data distribution service (see output.rs comments for websocket/depth integration architecture).

8. **processor**: Processes match results - updates databases, manages asset changes, handles on-chain interactions, and forwards to websocket.

9. **depth**: Manages orderbook depth snapshots and price level aggregation for real-time distribution.

10. **onchain_msg**: Handles blockchain interactions and on-chain message processing.

### Data Flow

```
User Request → API → Redis Stream (order_input_stream)
                ↓
         Match Engine (in-memory orderbook matching)
                ↓
    ┌───────────┼───────────────┬──────────┐
    ↓           ↓               ↓          ↓
Store Stream  Processor   Websocket   Cache Stream
    ↓           ↓           Stream        ↓
   Store    Processor    Websocket     Depth
 Service    Service      Service      Service
```

### Message Passing

The system uses Redis Streams with consumer groups for reliable message delivery:

- **order_input_stream**: Orders from API to match_engine (with deduplication via SlidingWindowDedup)
- **market_input_stream**: Market lifecycle events
- **store_stream**: Order changes for persistence
- **processor_stream**: Match results for asset/DB updates
- **websocket_stream**: Real-time updates for clients
- **cache_stream**: Depth snapshots for queries

Consumer groups with multiple consumers handle high throughput. Pending messages are claimed on startup to ensure reliability.

### Key Design Patterns

1. **Shared State**: Services use `Arc<RwLock<T>>` for thread-safe shared state (e.g., OrderStorage, Manager).

2. **Channel-based Routing**: match_engine uses hash-based routing to distribute work across tokio tasks - each market's orders go to a dedicated task with an orderbook instance.

3. **Graceful Shutdown**: All services monitor SIGINT/SIGTERM via broadcast channels and cleanly finish processing before exit.

4. **Configuration**: Environment-based config via `RUN_MODE` env var (dev/prod). Config files in `deploy/<service>/{dev,prod}.toml` loaded via the `config` crate.

5. **Snapshot Recovery**: store service periodically saves orderbook state to JSON. On restart, match_engine loads from snapshot and resumes from last processed message ID.

## Common Module

The `common` crate contains shared types and utilities:

- `engine_types`: Core order/market types (Order, OrderSide, OrderType, OrderStatus, PredictionSymbol)
- `processor_types`: Messages for processor service (OrderSubmitted, OrderTraded, OrderCancelled)
- `store_types`: Order change events for store service
- `websocket_types`: Real-time update messages
- `cache_types`: Orderbook depth representations
- `market_types`: Market lifecycle messages
- `model`: Database model definitions (sqlx)
- `redis_pool`, `postgres_pool`: Connection pool utilities
- `logging`: Structured logging setup with tracing
- `rate_limit`, `redis_lock`: Utility modules

## Symbol Format

Market symbols use format: `market_id|option_id|token_id` (separator defined in `common/src/consts.rs` as `SYMBOL_SEPARATOR = "|"`).

## Database

PostgreSQL schema defined in `script/database.sql`. Services use sqlx with macros for compile-time query verification.

## Configuration Files

All services read from `deploy/common.env` for shared config (Redis/Postgres connection strings) and service-specific configs in `deploy/<service>/{dev,prod}.toml`.

Example config structure:
```toml
[logging]
level = "info"
file = "./logs/service.log"
console = true
rotation_max_files = 3

[engine_input_mq]
db = 0
batch_size = 100
```

## Critical Implementation Notes

1. **Order Matching**: Uses BTreeMap for price levels with negative keys for buy side (descending price priority). Orders at same price level matched FIFO (time priority).

2. **Atomicity**: store service updates orders/markets and last_message_id under single RwLock to ensure consistency.

3. **Deduplication**: match_engine implements SlidingWindowDedup (see helper.rs) to prevent duplicate order processing.

4. **Output Throughput**: output task count should be > input consumer count. Uses hash-based task routing for balanced distribution.

5. **No WAL in match_engine**: Design commentary in input.rs explains trade-offs - relies on Redis Stream reliability and graceful shutdown rather than write-ahead logging.

6. **Snapshot Timing**: store service reads data under read lock, releases lock, then serializes/writes file. Calls `sync_all()` to ensure disk flush.

7. **Stream Cleanup**: store service periodically trims Redis Streams after successful snapshot to prevent unbounded growth.

## Proto

The `proto` crate uses tonic/prost for gRPC service definitions. Run `cargo build -p proto` to regenerate protobuf code from build.rs.

## Logging

All services use tracing with JSON formatting. Log levels and rotation configured per service. Logs written to `./logs/<service>.log` with configurable rotation (default 3 files).

## Error Handling

Services use anyhow for error propagation. Match engine publishes OrderRejected messages to processor stream for failed orders (validation errors, market closed, etc).

## Testing

Integration tests in `match_engine/tests/` verify orderbook behavior. When writing tests, use the match_engine as a library crate (it exports all modules via lib.rs).

## WebSocket Services

The system includes two WebSocket services for real-time data distribution:

### websocket_depth

Provides real-time orderbook depth data for prediction markets.

**Connection Flow:**
1. Client connects to `/depth` endpoint
2. Server immediately sends connection confirmation:
   ```json
   {
     "event_type": "connected",
     "id": "<connection-uuid>"
   }
   ```
3. Client sends subscription message to receive depth updates:
   ```json
   {
     "action": "subscribe",
     "event_id": 1,
     "market_id": 1
   }
   ```
4. Server responds with subscription confirmation and current depth snapshot
5. Client receives real-time price updates as orders are matched
6. Client must send text message `"ping"` every 30 seconds as heartbeat (not WebSocket Ping frame)

**Unsubscribe:**
```json
{
  "action": "unsubscribe",
  "event_id": 1,
  "market_id": 1
}
```

### websocket_user

Provides real-time user-specific updates (orders, trades, position changes).

**Connection Flow:**
1. Client connects to `/user` endpoint
2. Server immediately sends connection confirmation:
   ```json
   {
     "event_type": "connected",
     "id": "<connection-uuid>"
   }
   ```
3. Client must authenticate with Privy JWT token:
   ```json
   {
     "auth": "<privy-jwt-token>"
   }
   ```
4. Server validates token and responds:
   ```json
   {
     "event_type": "auth",
     "success": true
   }
   ```
5. After authentication, server automatically pushes user-specific updates
6. Client must send text message `"ping"` every 30 seconds as heartbeat (not WebSocket Ping frame)

**Important Notes:**
- Both services expect heartbeat as **text message** `"ping"`, not WebSocket protocol Ping frames
- websocket_user requires Privy JWT authentication before receiving any data
- Heartbeat timeout: 60 seconds (configurable via `HEARTBEAT_TIMEOUT_SECS`)
- Heartbeat check interval: 30 seconds (configurable via `HEARTBEAT_CHECK_INTERVAL_SECS`)
- Connection closes automatically on heartbeat timeout or authentication failure

**Mock Clients:**
- `script/mock/mock_go/websocket_depth/main.go` - Example depth subscription client
- `script/mock/mock_go/websocket_user/main.go` - Example user authentication client (requires `PrivyToken` constant to be set)
